namespace qcloudsms_csharp.httpclient
{
    public enum HTTPMethod
    {
        GET,
        POST,
        HEAD,
        PATCH,
        PUT,
        DLETE,
        OPTIONS
    }
}